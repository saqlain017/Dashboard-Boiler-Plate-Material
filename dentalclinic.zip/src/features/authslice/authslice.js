import { createSlice,createAsyncThunk } from "@reduxjs/toolkit";

const initialState = {
    isLoggedIn : false
}

export const HandleSignIn = createAsyncThunk(
    'auth/signin',
    (_,thunkAPI)=>{
        try{
            localStorage.setItem("token","Keep Logged In My Prototype");    
            return thunkAPI.dispatch(authSlice.actions.handleLogin())
        }catch(error){
            return thunkAPI.rejectWithValue(error)
        }
    }
)
export const HandleSignOut = createAsyncThunk(
    'auth/signout',
    (_,thunkAPI)=>{
        try{
            localStorage.removeItem("token");  
            return thunkAPI.dispatch(authSlice.actions.handleLogout())
        }catch(error){
            return thunkAPI.rejectWithValue(error)
        }
    }
)

export const authSlice =  createSlice({
    name : 'auth',
    initialState,
    reducers: {
        clearState : ()=> initialState,
        handleLogin : (state)=>{
            state.isLoggedIn = true
        },
        handleLogout : (state)=>{
            state.isLoggedIn = false
        }
    }
})

export const {clearState,handleLogin,handleLogout} = authSlice.actions;
export default authSlice.reducer